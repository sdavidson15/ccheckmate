COM S 352 Section C Project 1: Shear Sort
=========================================

### How to Run

All input files are expected to have the filename `input.txt` and exist in the same directory as the source code.
This is not configurable without code changes.

`make run` cleans out any old builds, rebuilds, and runs the program.
`make clean` cleans out any old builds.

`make` hits the `make run` target.

### Author
Stephen Davidson scd@iastate.edu




